
dan = prompt("원하는 단은? ",2);
flag=confirm(dan+ "단을 보시겠나이까");
if(flag ==false){
    document.writeln("꺼져 ^ ^ ");
}else{

    document.write("<br><br>"+dan+"단       <br><br>");
    for(var j =1;j<10;j++)
    {
        document.write(dan + "x" +j + "="+ dan*j + "<br>");
    }
    document.writeln("");
}