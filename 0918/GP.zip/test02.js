alert("자바 스크립트 대화상자");
dan = prompt("원하는 단은? ",2);
confirm("참 거짓을 결정하는 대화상자");

for(var i= 2;i< 10 ;i++)
{
    document.write("<br><br>"+i+"단       <br><br>");
    for(var j =1;j<10;j++)
    {
        document.write(i + "x" +j + "="+ i*j + "<br>");
    }
    document.writeln("");
}