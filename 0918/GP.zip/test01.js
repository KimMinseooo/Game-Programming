var my_job ="사장";

switch(my_job)
{
	case "사장":
		money = 100000;
			break;
	case "아르바이트생":
		money = 100000;
			break;
	case "학생":
		money = 102000;
			break;
	default:
		money = 100000;
			break;
};

document.writeln("");
document.writeln("나의 직업은 "+my_job+"이고 나의 현재 금액은"+money);